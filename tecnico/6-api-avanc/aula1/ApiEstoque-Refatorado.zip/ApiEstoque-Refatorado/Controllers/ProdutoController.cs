using ApiEstoque.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/produtos")]
public class ProdutoController : ControllerBase {
    private readonly IProdutoService _service;

    public ProdutoController(IProdutoService service) {
        _service = service;
    }

    [HttpGet]
    public async Task<IActionResult> Get() {
        var resultado = await _service.ObterTodosProdutosAsync();
        
        // Se a lista estiver vazia, retornamos 204 (No Content) ou 200 com lista vazia
        return Ok(resultado); 
    }
}