using System;
using ApiEstoque.Entities;
using Microsoft.EntityFrameworkCore;

namespace ApiEstoque.Infra.Context;

public class LojaDbContext : DbContext
{
    public LojaDbContext(DbContextOptions<LojaDbContext> options) : base(options) { }

    public DbSet<Produto> Produtos { get; set; }
    public DbSet<Fabricante> Fabricantes { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Produto>(entity =>
        {
            entity.ToTable("produtos");
            entity.HasKey(p => p.Id);

            entity.Property(p => p.Id)
                  .HasColumnName("id");

            entity.Property(p => p.FabricanteId)
                  .HasColumnName("fabricanteid"); // Nome exato como está no Postgres

            entity.Property(p => p.Nome)
                  .HasColumnName("nome");

            entity.Property(p => p.Preco)
                  .HasColumnName("preco");

            entity.HasOne(p => p.Fabricante)
                  .WithMany(f => f.Produtos)
                  .HasForeignKey(p => p.FabricanteId);
        });

        modelBuilder.Entity<Fabricante>(entity =>
        {
            entity.ToTable("fabricantes");

            entity.Property(f => f.Id)
                .HasColumnName("id");

            entity.Property(f => f.Nome)
                .HasColumnName("nome");
    });
    }
}