using System;

namespace ApiEstoque.Infra.DTOs;

public class ProdutoResponseDTO {
    public string? Nome { get; set; }
    public decimal Preco { get; set; }
    public string? NomeFabricante { get; set; }
}
