using System;
using ApiEstoque.Entities;

namespace ApiEstoque.Infra.Repositories.Interfaces;

public interface IProdutoRepository {
    Task<IEnumerable<Produto>> ListarTodosAsync();
}
