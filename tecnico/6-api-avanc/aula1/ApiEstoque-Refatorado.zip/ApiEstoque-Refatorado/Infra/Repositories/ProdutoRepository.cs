using System;
using ApiEstoque.Entities;
using ApiEstoque.Infra.Context;
using ApiEstoque.Infra.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace ApiEstoque.Infra.Repositories;

public class ProdutoRepository : IProdutoRepository {
    private readonly LojaDbContext _context;
    public ProdutoRepository(LojaDbContext context) { _context = context; }

    public async Task<IEnumerable<Produto>> ListarTodosAsync() {
        // Eager Loading: Trazendo o fabricante em um único JOIN
        return await _context.Produtos
                             .Include(p => p.Fabricante)
                             .ToListAsync();
    }
}