using System;
using ApiEstoque.Infra.DTOs;
using ApiEstoque.Infra.Repositories.Interfaces;
using ApiEstoque.Services.Interfaces;

namespace ApiEstoque.Services;

public class ProdutoService : IProdutoService {
    private readonly IProdutoRepository _repository;

    public ProdutoService(IProdutoRepository repository) {
        _repository = repository;
    }

    public async Task<IEnumerable<ProdutoResponseDTO>> ObterTodosProdutosAsync() {
        // 1. Busca os dados brutos no repositório
        var produtos = await _repository.ListarTodosAsync();

        // 2. Transforma (Mapeia) Entidades em DTOs
        // Aqui você explica que isso protege a Entidade do Banco
        var produtosDto = produtos.Select(p => new ProdutoResponseDTO {
            Nome = p.Nome,
            Preco = p.Preco,
            NomeFabricante = p.Fabricante?.Nome
        });

        return produtosDto;
    }
}
