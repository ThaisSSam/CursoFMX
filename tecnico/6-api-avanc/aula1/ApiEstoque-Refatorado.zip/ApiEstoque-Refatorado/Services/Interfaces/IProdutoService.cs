using System;
using ApiEstoque.Infra.DTOs;

namespace ApiEstoque.Services.Interfaces;

public interface IProdutoService {
    Task<IEnumerable<ProdutoResponseDTO>> ObterTodosProdutosAsync();
}
