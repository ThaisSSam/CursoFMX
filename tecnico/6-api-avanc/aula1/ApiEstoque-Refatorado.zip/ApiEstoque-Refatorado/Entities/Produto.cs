using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace ApiEstoque.Entities;

public class Produto {
    public int Id { get; set; }
    public string? Nome { get; set; }
    public decimal Preco { get; set; }
    public int FabricanteId { get; set; }
    public Fabricante? Fabricante { get; set; }
}
