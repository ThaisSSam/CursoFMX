using System;

namespace ITB.Application.Dtos;

public class FabricanteCreateDto
{
    public string Nome { get; set; } = string.Empty;
    //public string Cnpj { get; set; } = string.Empty;
}
