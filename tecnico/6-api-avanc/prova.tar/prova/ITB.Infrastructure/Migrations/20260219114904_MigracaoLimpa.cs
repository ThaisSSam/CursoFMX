﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ITB.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class MigracaoLimpa : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_veiculos_marcas_idMarcaid",
                table: "veiculos");

            migrationBuilder.DropIndex(
                name: "IX_veiculos_idMarcaid",
                table: "veiculos");

            migrationBuilder.RenameColumn(
                name: "idMarcaid",
                table: "veiculos",
                newName: "marcaId");

            migrationBuilder.AlterColumn<int>(
                name: "ano",
                table: "veiculos",
                type: "integer",
                nullable: false,
                oldClrType: typeof(DateTime),
                oldType: "timestamp with time zone");

            migrationBuilder.AddColumn<int>(
                name: "MarcaId",
                table: "veiculos",
                type: "integer",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_veiculos_MarcaId",
                table: "veiculos",
                column: "MarcaId");

            migrationBuilder.AddForeignKey(
                name: "FK_veiculos_marcas_MarcaId",
                table: "veiculos",
                column: "MarcaId",
                principalTable: "marcas",
                principalColumn: "id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_veiculos_marcas_MarcaId",
                table: "veiculos");

            migrationBuilder.DropIndex(
                name: "IX_veiculos_MarcaId",
                table: "veiculos");

            migrationBuilder.DropColumn(
                name: "MarcaId",
                table: "veiculos");

            migrationBuilder.RenameColumn(
                name: "marcaId",
                table: "veiculos",
                newName: "idMarcaid");

            migrationBuilder.AlterColumn<DateTime>(
                name: "ano",
                table: "veiculos",
                type: "timestamp with time zone",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer");

            migrationBuilder.CreateIndex(
                name: "IX_veiculos_idMarcaid",
                table: "veiculos",
                column: "idMarcaid");

            migrationBuilder.AddForeignKey(
                name: "FK_veiculos_marcas_idMarcaid",
                table: "veiculos",
                column: "idMarcaid",
                principalTable: "marcas",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
