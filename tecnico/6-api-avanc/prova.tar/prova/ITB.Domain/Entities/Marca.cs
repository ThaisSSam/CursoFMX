using System;

namespace ITB.Domain.Entities;

public class Marca
{
    public int id { get; set;}

    public string nome { get; set;} = string.Empty;
}
