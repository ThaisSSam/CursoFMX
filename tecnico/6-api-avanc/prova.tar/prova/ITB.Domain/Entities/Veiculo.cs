using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace ITB.Domain.Entities;

public class Veiculo
{
    public int id { get; set;}

    public string nome { get; set;}
    public string modelo { get; set;}
    public string placa { get; set;}
    public int ano { get; set;}
    public int marcaId { get; set;}
    
    [ForeignKey("MarcaId")]
    public Marca idMarca { get; set; }
}
