import { createStore } from "zustand/vanilla";

export type MensagemZustandState = {
  mensagem: string;
  definirMensagem: (texto: string) => void;
  limparMensagem: () => void;
};

export const mensagemZustandStore = createStore<MensagemZustandState>((set) => ({
  mensagem: "",
  definirMensagem: (texto) => set({ mensagem: texto }),
  limparMensagem: () => set({ mensagem: "" }),
}));
