import { createContext } from "react";

export type MensagemContextType = {
  mensagem: string;
  definirMensagem: (texto: string) => void;
  limparMensagem: () => void;
};

export const MensagemContext = createContext<MensagemContextType | undefined>(
  undefined,
);
