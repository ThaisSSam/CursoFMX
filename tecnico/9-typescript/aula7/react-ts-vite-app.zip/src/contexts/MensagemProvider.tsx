import { useState, type ReactNode } from "react";
import { MensagemContext } from "./mensagemContext";

export function MensagemProvider({ children }: { children: ReactNode }) {
  const [mensagem, setMensagem] = useState("");

  return (
    <MensagemContext.Provider
      value={{
        mensagem,
        definirMensagem: (texto) => setMensagem(texto),
        limparMensagem: () => setMensagem(""),
      }}
    >
      {children}
    </MensagemContext.Provider>
  );
}
