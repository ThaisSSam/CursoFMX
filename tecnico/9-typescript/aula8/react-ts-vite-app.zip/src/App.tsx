import { Route, Routes } from "react-router-dom";
import { Home } from "./pages/Home";
import { UsuariosFetch } from "./pages/UsuariosFetch";
import { UsuariosAxios } from "./pages/UsuariosAxios";

export default function App() {
  return (
    <main className="app-shell">
      {/* <h1>Navegacao e consumo de API</h1>
      <nav className="menu">
        <Link to="/">Home</Link>
        <Link to="/usuarios-fetch">Usuarios (fetch)</Link>
        <Link to="/usuarios-axios">Usuarios (axios)</Link>
      </nav> */}

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/usuarios-fetch" element={<UsuariosFetch />} />
        <Route path="/usuarios-axios" element={<UsuariosAxios />} />
      </Routes>
    </main>
  );
}
