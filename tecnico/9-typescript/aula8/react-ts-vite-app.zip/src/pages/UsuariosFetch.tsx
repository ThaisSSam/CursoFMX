import { useEffect, useState } from "react";

type Usuario = {
  id: number;
  name: string;
  email: string;
};

export function UsuariosFetch() {
  const [usuarios, setUsuarios] = useState<Usuario[]>([]);
  const [carregando, setCarregando] = useState(false);
  const [erro, setErro] = useState("");
  
  async function carregar() {
    try {
      setCarregando(true);
      setErro("");

      const resposta = await fetch("https://jsonplaceholder.typicode.com/users");
      if (!resposta.ok) {
        throw new Error("Falha ao buscar usuarios");
      }

      const dados = (await resposta.json()) as Usuario[];
      setUsuarios(dados);
    } catch {
      setErro("Nao foi possivel carregar usuarios");
    } finally {
      setCarregando(false);
    }
  }

  useEffect(() => {
    carregar();
  }, []);

  if (carregando) return <p>Carregando...</p>;
  if (erro) return <p>{erro}</p>;

  return (
    <section className="page-card">
      <h2>Usuarios com fetch</h2>
      <ul>
        {usuarios.map((u) => (
          <li key={u.id}>
            {u.name} - {u.email}
          </li>
        ))}
      </ul>
    </section>
  );
}
