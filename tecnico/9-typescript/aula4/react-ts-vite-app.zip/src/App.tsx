
function App() {

  return (
    <h1>Texto temporáio</h1>
  );
}

export default App;