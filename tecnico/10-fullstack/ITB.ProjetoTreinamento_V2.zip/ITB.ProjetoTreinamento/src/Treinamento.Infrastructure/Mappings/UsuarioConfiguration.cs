using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Treinamento.Domain.Aggregates.Usuarios;

namespace Treinamento.Infrastructure.Mappings;

internal class UsuarioConfiguration : IEntityTypeConfiguration<Usuario>
{
    public void Configure(EntityTypeBuilder<Usuario> builder)
    {
        builder.ToTable("tb_usuarios", "treinamento");

        builder.HasKey(u => u.Id)
            .HasName("pk_tb_usuarios_id");

        builder.Property(u => u.Id)
            .HasColumnName("id")
            .ValueGeneratedOnAdd();

        builder.Ignore(u => u.ResultadoValidacao);
    }
}
