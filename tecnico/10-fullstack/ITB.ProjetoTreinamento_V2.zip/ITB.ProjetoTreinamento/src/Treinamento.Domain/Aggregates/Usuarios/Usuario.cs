using Treinamento.Domain.Core.Entities;

namespace Treinamento.Domain.Aggregates.Usuarios;

/// <summary>
/// Agregado de usuário — base do Módulo 1 (US001).
/// No boilerplate contém apenas <see cref="Id"/>; os alunos acrescentam e-mail, senha, situação, etc.
/// </summary>
public class Usuario : Entity<Usuario>
{
    protected Usuario()
    {
    }

    public override bool EhValido() => true;
}
